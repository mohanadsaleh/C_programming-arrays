#include <stdio.h>
#include <string.h>



int main(void) {
    
    char cumle [100];

    
    printf(": cumle veya kelime giriniz ");
    fgets(cumle, 100, stdin);

   
    cumle[strcspn(cumle, "\n")] = 0;

    for (int i = 0; i < strlen(cumle); i++) {
        printf("%c%c", cumle[i], cumle[i]);
    }
    printf("\n");

    return 0;
}